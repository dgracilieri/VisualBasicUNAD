﻿Public Class areas

   
    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim calculo As Double
        If ComboBox1.SelectedItem = "" Then
            MsgBox("Error debe seleccionar una figura", MessageBoxIcon.Error)
            TextBox1.Text = ""
            TextBox2.Text = ""

        ElseIf ComboBox1.SelectedItem = "Cuadrado" Or ComboBox1.SelectedItem = "Rectangulo" Then
            If TextBox1.Text = "" Or TextBox2.Text = "" Then
                MsgBox("Error debe ingresar la base y la altura", MessageBoxIcon.Error)
            Else
                calculo = Val(TextBox1.Text) * Val(TextBox2.Text)
                MsgBox("El area de la figura seleccionada es " + calculo.ToString, MsgBoxStyle.OkOnly)
            End If
            
            TextBox1.Text = ""
            TextBox2.Text = ""
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Then
                MsgBox("Error debe ingresar la base y la altura", MessageBoxIcon.Error)
            Else
                calculo = (Val(TextBox1.Text) * Val(TextBox2.Text)) / 2
                MsgBox("El area de la figura seleccionada es " + calculo.ToString, MsgBoxStyle.OkOnly)
            End If
            
            TextBox1.Text = ""
            TextBox2.Text = ""
            End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
    End Sub
End Class