﻿Public Class Menu

    Private Sub CalculaVelocidadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CalculaVelocidadToolStripMenuItem.Click

    End Sub

    Private Sub SalirToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SalirToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub CalculaVelocidadToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CalculaVelocidadToolStripMenuItem1.Click
        velocidad.Show()
    End Sub

    Private Sub CalculaAreasToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CalculaAreasToolStripMenuItem.Click
        areas.Show()
    End Sub

    Private Sub ConversorDeMedidasToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConversorDeMedidasToolStripMenuItem.Click
        convierte.Show()
    End Sub
End Class
