﻿Public Class velocidad

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim tiempo As Double
        Dim vel As Double
        Dim dist As Double

        If TextBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" Then
            MsgBox("Error debe ingresar datos en dos campos", MessageBoxIcon.Error)
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
        ElseIf TextBox1.Text = "" And TextBox2.Text = "" And TextBox3.Text = "" Then

            MsgBox("Error debe ingresar datos en al menos dos campos", MessageBoxIcon.Error)
        ElseIf TextBox1.Text = "" And TextBox2.Text = "" Then
            MsgBox("Error debe ingresar datos en al menos dos campos", MessageBoxIcon.Error)
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
        ElseIf TextBox1.Text = "" And TextBox3.Text = "" Then
            MsgBox("Error debe ingresar datos en al menos dos campos", MessageBoxIcon.Error)
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
        ElseIf TextBox2.Text = "" And TextBox3.Text = "" Then
            MsgBox("Error debe ingresar datos en al menos dos campos", MessageBoxIcon.Error)
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
        ElseIf TextBox1.Text <> "" And TextBox2.Text <> "" Then
            tiempo = Val(TextBox1.Text) / Val(TextBox2.Text)
            MsgBox("El tiempo calculado es de " + tiempo.ToString + " Segundos")
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
        ElseIf TextBox1.Text <> "" And TextBox3.Text <> "" Then
            vel = Val(TextBox1.Text) / Val(TextBox3.Text)
            MsgBox("La velocidad calculada es " + vel.ToString + " M/seg")
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
        ElseIf TextBox2.Text <> "" And TextBox3.Text <> "" Then
            dist = Val(TextBox2.Text) * Val(TextBox3.Text)
            MsgBox("La distancia calculada es " + dist.ToString + " Metros")
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""

        End If



    End Sub
    'Solo permite ingresar datos numericos
    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    'Solo permite ingresar datos numericos
    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
    'Solo permite ingresar datos numericos
    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        If Not IsNumeric(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
End Class