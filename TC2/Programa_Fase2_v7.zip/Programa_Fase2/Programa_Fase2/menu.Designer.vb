﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class menu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuOpcionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ArrayToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Op1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Op2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Op3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Op4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Op5ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Op6ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Op8ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Op9ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpracionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuOpcionesToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(884, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuOpcionesToolStripMenuItem
        '
        Me.MenuOpcionesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArrayToolStripMenuItem, Me.Op1ToolStripMenuItem, Me.Op2ToolStripMenuItem, Me.Op3ToolStripMenuItem, Me.Op4ToolStripMenuItem, Me.Op5ToolStripMenuItem, Me.Op6ToolStripMenuItem, Me.Op8ToolStripMenuItem, Me.Op9ToolStripMenuItem, Me.OpracionesToolStripMenuItem})
        Me.MenuOpcionesToolStripMenuItem.Name = "MenuOpcionesToolStripMenuItem"
        Me.MenuOpcionesToolStripMenuItem.Size = New System.Drawing.Size(101, 20)
        Me.MenuOpcionesToolStripMenuItem.Text = "Menu opciones"
        '
        'ArrayToolStripMenuItem
        '
        Me.ArrayToolStripMenuItem.Name = "ArrayToolStripMenuItem"
        Me.ArrayToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.ArrayToolStripMenuItem.Text = "Agenda"
        '
        'Op1ToolStripMenuItem
        '
        Me.Op1ToolStripMenuItem.Name = "Op1ToolStripMenuItem"
        Me.Op1ToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.Op1ToolStripMenuItem.Text = "Calculo de distancia"
        '
        'Op2ToolStripMenuItem
        '
        Me.Op2ToolStripMenuItem.Name = "Op2ToolStripMenuItem"
        Me.Op2ToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.Op2ToolStripMenuItem.Text = "Capitales Sudamerica"
        '
        'Op3ToolStripMenuItem
        '
        Me.Op3ToolStripMenuItem.Name = "Op3ToolStripMenuItem"
        Me.Op3ToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.Op3ToolStripMenuItem.Text = "Presupuesto"
        '
        'Op4ToolStripMenuItem
        '
        Me.Op4ToolStripMenuItem.Name = "Op4ToolStripMenuItem"
        Me.Op4ToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.Op4ToolStripMenuItem.Text = "Valida palabras"
        '
        'Op5ToolStripMenuItem
        '
        Me.Op5ToolStripMenuItem.Name = "Op5ToolStripMenuItem"
        Me.Op5ToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.Op5ToolStripMenuItem.Text = "Multiplicacion de matrices"
        '
        'Op6ToolStripMenuItem
        '
        Me.Op6ToolStripMenuItem.Name = "Op6ToolStripMenuItem"
        Me.Op6ToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.Op6ToolStripMenuItem.Text = "Calificaciones"
        '
        'Op8ToolStripMenuItem
        '
        Me.Op8ToolStripMenuItem.Name = "Op8ToolStripMenuItem"
        Me.Op8ToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.Op8ToolStripMenuItem.Text = "Adivina"
        '
        'Op9ToolStripMenuItem
        '
        Me.Op9ToolStripMenuItem.Name = "Op9ToolStripMenuItem"
        Me.Op9ToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.Op9ToolStripMenuItem.Text = "Escalar"
        '
        'OpracionesToolStripMenuItem
        '
        Me.OpracionesToolStripMenuItem.Name = "OpracionesToolStripMenuItem"
        Me.OpracionesToolStripMenuItem.Size = New System.Drawing.Size(214, 22)
        Me.OpracionesToolStripMenuItem.Text = "Opraciones"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(387, 103)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(287, 24)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "TRABAJO COLABORATIVO 2"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Programa_Fase2.My.Resources.Resources.Logo_UNAD
        Me.PictureBox1.Location = New System.Drawing.Point(29, 46)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(263, 86)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(884, 561)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(900, 600)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(900, 600)
        Me.Name = "menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Programa Fase 2"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MenuOpcionesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ArrayToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Op1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Op2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Op3ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Op4ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Op5ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Op6ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Op8ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Op9ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents OpracionesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
