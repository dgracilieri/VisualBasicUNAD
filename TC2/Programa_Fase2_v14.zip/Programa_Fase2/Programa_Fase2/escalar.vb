﻿Public Class escalar

End Class